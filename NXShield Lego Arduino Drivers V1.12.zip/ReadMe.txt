/*
*  Matthew Richardson
*  matthewrichardson37<at>gmail.com
*  http://mattallen37.wordpress.com/
*
*  You may use the code as you wish, provided you give credit where it's due.
*
*  ReadMe for NXShield_Lego_Arduino_Drivers version 1.12
*/

These drivers and examples are to be used with the NXShield (by openelectrons.com), in addition to the libraries from openelectrons.

All drivers and examples have been tested with arduino-1.0.1, NXShield-0.1.01, and an Arduino Mega 2560 with NXShield-M.

Place the folder "NXShield_Lego_Arduino_Drivers" in the libraries folder of the arduino directory, usually something like C:\Program Files (x86)\arduino-1.0\libraries